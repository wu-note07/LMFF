# RDE-MBRS: 轻量化鲁棒图像水印

在 MBRS（Mini-Batch of Real and Simulated JPEG Compression）框架上，将编码器 / 解码器的特征提取主干替换为
**RDE 模块（Res2Net 多尺度结构 + 深度可分离卷积 + ECA 通道注意力）**，在保持鲁棒性的同时大幅降低参数量。

## 网络结构

| 文件 | 作用 |
| --- | --- |
| `network/blocks/SERes2Net.py` | **RDE 模块**：`ECABlock`（ECA 通道注意力）、`BottleneckBlock`、`SERes2NetBlock`（Res2Net split + DW/PW 深度可分离卷积 + ECA）、`SERes2Net` / `SERes2Net_decoder` |
| `network/Encoder_MP.py` | 编码器：`Encoder_MP`（完整版）与 `Encoder_MP_Diffusion`（轻量化版） |
| `network/Decoder.py` | 解码器：`Decoder`（完整版）与 `Decoder_Diffusion`（轻量化版） |
| `network/Discriminator.py` | 判别器（4 层卷积 + 全局池化 + 全连接） |
| `network/Encoder_MP_Decoder.py` | 编码器 + 噪声层 + 解码器的容器 |
| `network/Network.py` | 整体封装（优化器、损失、训练 / 测试流程） |
| `network/noise_layers/` | 噪声层：Identity / Jpeg / JpegMask / Crop / Cropout / Dropout / GF / Combined |

`with_diffusion=True` 时使用 `Encoder_MP_Diffusion + Decoder_Diffusion`，即论文中的轻量化编解码器。

## 参数量（H = W = 128，message_length = 64）

| 模块 | 参数量 |
| --- | --- |
| Encoder_MP_Diffusion | 526,760 |
| Decoder_Diffusion | 3,424,819 |
| Discriminator | 135,729 |
| **合计** | **4,087,308** |

对比完整版编解码器（`with_diffusion=False`）合计约 13.58M，参数量降低约 70%。

## 环境依赖

```
Python >= 3.8
torch >= 1.8
torchvision
kornia
opencv-python
Pillow
numpy
```

安装示例：

```bash
pip install torch torchvision kornia opencv-python Pillow numpy
```

## 数据准备

目录结构：

```
datasets/
├── train/        # 训练集图像（建议使用 DIV2K 训练集）
└── validation/   # 验证集图像

X2/
└── test/         # 测试集图像
```

- 训练读取 `train_settings.json` 的 `dataset_path`，其下需要 `train/` 与 `validation/` 两个子目录
- 测试读取 `test_settings.json` 的 `dataset_path`（默认 `./X2/test`）
- 数据集体积大，已在 `.gitignore` 中忽略，clone 后需自行放置

## 训练

```bash
python train.py
```

结果（`*.pth`、可视化图片）保存在 `results/<项目名_时间戳>/` 下。

## 测试

1. 把 `test_settings.json` 的 `result_folder` 改为你的训练结果目录（如 `MBRS_m64_Diffusion/`，会自动拼到 `results/` 下）
2. 确保该目录下存在 `models/EC_<model_epoch>.pth`，且 `message_length`、`with_diffusion` 与训练时一致
3. 运行：

```bash
python test.py
```

## 配置说明

`train_settings.json`：

| 字段 | 说明 |
| --- | --- |
| `with_diffusion` | `true` 使用轻量化编解码器（论文模型），`false` 使用完整版 |
| `message_length` | 水印长度，默认 64；论文表 4-1 的参数量对应 64 bit |
| `noise_layers` | 训练时使用的噪声层组合 |
| `dataset_path` | 训练集路径 |

## 致谢与来源声明

本项目基于以下开源工作修改：

- **MBRS**: Jia et al., *MBRS: Enhancing Robustness of DNN-based Watermarking by Mini-Batch of Real and Simulated JPEG Compression*, ACM MM 2021
- **HiDDeN**: Zhu et al., *HiDDeN: Hiding Data With Deep Networks*, ECCV 2018

原项目代码版权归原作者所有，使用与分发请遵循原项目许可协议。本仓库仅包含论文实现的网络与训练代码，不包含数据集与训练权重。
